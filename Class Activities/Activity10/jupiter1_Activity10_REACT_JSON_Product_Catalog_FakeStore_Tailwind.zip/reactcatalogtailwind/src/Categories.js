// Categories.js
/**
 * Author: Juan Figueroa
ISU Netid : jupiter1@iastate.edu
Date : March 27th, 2024
**/
export default [
    "electronics",
    "jewelery",
    "men's clothing",
    "women's clothing"
  ];